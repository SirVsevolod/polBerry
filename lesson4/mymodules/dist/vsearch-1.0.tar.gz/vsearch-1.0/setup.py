from setuptools import setup

setup(name = 'vsearch',
      version='1.0',
      description='The Head First Python Search Tools',
      author='HF python 2e',
      author_email='hfpy2e@gmail.com',
      py_modules=['vsearch'],
      )